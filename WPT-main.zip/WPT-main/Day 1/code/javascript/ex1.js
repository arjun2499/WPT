console.log("hello world")
let x
//x="flowers"
//x='flowers'
x=`this is a long string
with new lines use backquotes 
for multiline strings `

x=new String("hello")
x=true
x=[10,20,30,true,"russia"]

console.log("x=",x, typeof(x))