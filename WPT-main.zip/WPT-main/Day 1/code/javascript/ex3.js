x = 4

// if(x%2 == 0)
//   console.log(x," is even")
// else
//    console.log(x," is odd")

// switch(x)
// {
//     case 1: console.log("one");break;
//     case 2: console.log("two")
//             break
//     default : console.log("not 1 or 2")
//               break;
// }

// let a=1
// while(a++ < 10)
//  {
//     console.log(a)
//  }

// a=2
// do{
//  console.log(a++)
// }while(a < 10)


// for(let cnt=0;cnt<10;cnt++)
// {
//     console.log(cnt)
// }
























