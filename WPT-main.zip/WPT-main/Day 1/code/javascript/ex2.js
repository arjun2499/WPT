const x =44
//x=33
console.log(x)

var p=100
{
   // var p = 200
   let p=200

}
console.log("p=",p)

console.log(g)  //USAGE
//let g =10 //DECLARATION
var g  //DECLARATION using var