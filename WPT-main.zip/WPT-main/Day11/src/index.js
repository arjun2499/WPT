import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App2 from './day3/App2';
import App3 from './day4/App3';
import App4 from './day4/App4';
//import App from './App';
//import App1 from './day2/App1';

const div = ReactDOM.createRoot(document.getElementById('root'));
//div.render(  <App /> );
//div.render(<App1 />)
//div.render(<App2></App2>)
//div.render(<App3></App3>)
div.render(<App4></App4>)

