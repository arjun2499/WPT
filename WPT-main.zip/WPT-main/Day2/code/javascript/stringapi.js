let s = "hotspot"

//string is IMMUTABLE in JS 
console.log(s.toUpperCase())
console.log(s.toLowerCase())
console.log(s.charAt(2))
console.log(s.substring(3))
console.log(s.substring(2,-1))

console.log(s.slice(4))