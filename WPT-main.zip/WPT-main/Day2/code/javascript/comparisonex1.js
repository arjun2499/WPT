//let s = "rainbow"
//let s1 = new String("rainbow")

/*
let s = "rainbow"
let s1 ="rainbow"
*/
/*
let s = new String( "rainbow" )
let s1 =new String("rainbow")
*/
/*
let s = "rainbow"
let s1 =new String("rainbow")
*/

//if(s === s1)
if(s == s1)
  console.log("same")
else
  console.log("different")


  