import "./ex1.css"
export default function EduDetails()
{



    return(
        <div className="inner">
            SSC : 80%
            <br></br>
            HSC : 89%
            <br></br>
            CET :89.12
        </div>
    )

}