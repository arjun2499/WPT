export default function Welcome()
{
    return(
        <>
        <p>Hello Prachi</p>
        <p>Welcome to React</p>
        </>
    )
}


export function Greeting()
{
    return (<p>Good Morning</p>)
}