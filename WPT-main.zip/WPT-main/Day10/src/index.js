import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App2 from './day3/App2';
//import App from './App';
//import App1 from './day2/App1';

const div = ReactDOM.createRoot(document.getElementById('root'));
//div.render(  <App /> );
//div.render(<App1 />)
div.render(<App2></App2>)

