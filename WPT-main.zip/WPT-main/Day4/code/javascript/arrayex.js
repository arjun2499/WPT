let arr = [12,13,14]

arr.push(19,18,17)  // added at the end

console.log(arr)

let x =arr.pop()
console.log("x=",x)

arr.splice(3,2)
console.log(arr)

arr.splice(1,1,20,30)
console.log(arr)






















