//we can assign a function to a variable
let f1 = function ()
{
    console.log("hello")
}


f1() //call the function using variable name

//assign fat arrow function to variable f1 
let f2 = ()=>{ console.log("test again")}

f2();




