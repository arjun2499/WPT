import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
//import App from './App';
import App1 from './day2/App1';

const div = ReactDOM.createRoot(document.getElementById('root'));
//div.render(  <App /> );
div.render(<App1 />)

